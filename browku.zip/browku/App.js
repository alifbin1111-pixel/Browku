import React, { useRef, useState, useEffect } from "react";
import { View, Text, TextInput, Pressable, StyleSheet, FlatList, BackHandler, ToastAndroid } from "react-native";
import { WebView } from "react-native-webview";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { Ionicons as I } from "@expo/vector-icons";
import { StatusBar } from "expo-status-bar";
import { AD_HOSTS, inject } from "./adblock";

const C = { bg:"#0c171b", surf:"#122128", raise:"#183039", line:"#244551", text:"#e7eff1", mute:"#8fa8b0", cyan:"#5fd7e8", amber:"#ffb547" };
const ENGINES = [
  { n:"Startpage", u:q=>`https://www.startpage.com/sp/search?query=${q}&family=off` },
  { n:"DuckDuckGo", u:q=>`https://duckduckgo.com/?q=${q}&kp=-2` },
  { n:"Brave", u:q=>`https://search.brave.com/search?q=${q}&safesearch=off` },
  { n:"Bing", u:q=>`https://www.bing.com/search?q=${q}&adlt=off` },
];
const QUICK = [["Wikipedia","https://wikipedia.org"],["GitHub","https://github.com"],["Piped","https://piped.video"],["Reddit","https://old.reddit.com"],["Mojeek","https://mojeek.com"],["Archive","https://archive.org"]];

const host = u => { try { return new URL(u).hostname.replace(/^www\./,""); } catch { return u; } };
const root = h => h.split(".").slice(-2).join(".");
const isAd = h => AD_HOSTS.some(d => h === d || h.endsWith("." + d));
const mk = (src=null) => ({ id:String(Math.random()), src, cur:src||"", title:"Tab baru", p:0, b:false, f:false, n:0 });
const toast = m => ToastAndroid.show(m, ToastAndroid.SHORT);

export default function App() {
  const [tabs, setTabs] = useState(() => [mk()]);
  const [aid, setAid] = useState(null);
  const [shield, setShield] = useState(true);
  const [eng, setEng] = useState(0);
  const [focus, setFocus] = useState(false);
  const [text, setText] = useState("");
  const [sw, setSw] = useState(false);
  const refs = useRef({}), touch = useRef({});
  const T = useRef(tabs); T.current = tabs;
  const SH = useRef(shield); SH.current = shield;
  const id = aid ?? tabs[0].id;
  const tab = tabs.find(t => t.id === id) || tabs[0];
  const upd = (i, p) => setTabs(t => t.map(x => x.id === i ? { ...x, ...(typeof p === "function" ? p(x) : p) } : x));

  const toUrl = q => {
    q = q.trim();
    if (/^https?:\/\//i.test(q)) return q;
    if (/^[\w-]+(\.[\w-]+)+(\/\S*)?$/.test(q)) return "https://" + q;
    return ENGINES[eng].u(encodeURIComponent(q));
  };
  const go = q => {
    if (!q.trim()) return;
    const url = toUrl(q); touch.current[id] = Date.now();
    if (tab.src && refs.current[id]) refs.current[id].injectJavaScript(`location.href=${JSON.stringify(url)};true`);
    else upd(id, { src:url });
    upd(id, { cur:url }); setFocus(false);
  };
  const openTab = (url=null) => { const t = mk(url); if (url) touch.current[t.id] = Date.now(); if (T.current.length >= 8) return toast("Maksimal 8 tab"); setTabs(x => [...x, t]); setAid(t.id); setSw(false); };
  const closeTab = i => {
    const rest = tabs.filter(t => t.id !== i);
    if (!rest.length) { const n = mk(); setTabs([n]); setAid(n.id); return; }
    setTabs(rest); if (i === id) setAid(rest[rest.length - 1].id);
  };
  const toggleShield = () => { setShield(!shield); toast(shield ? "Perisai mati" : "Perisai aktif"); setTimeout(() => refs.current[id]?.reload(), 50); };

  useEffect(() => {
    const h = BackHandler.addEventListener("hardwareBackPress", () => {
      if (sw) { setSw(false); return true; }
      if (tab.b && refs.current[id]) { refs.current[id].goBack(); return true; }
      if (tab.src) { upd(id, { src:null, cur:"", title:"Tab baru" }); return true; }
      return false;
    });
    return () => h.remove();
  });

  const guard = tid => req => {
    let u; try { u = new URL(req.url); } catch { return false; }
    if (!/^https?:$/.test(u.protocol)) return false;
    if (!SH.current) return true;
    if (isAd(u.hostname)) { upd(tid, x => ({ n:x.n + 1 })); return false; }
    const cur = T.current.find(t => t.id === tid)?.cur;
    const fresh = Date.now() - (touch.current[tid] || 0) < 3000;
    if (cur && !fresh && root(host(cur)) !== root(u.hostname)) { upd(tid, x => ({ n:x.n + 1 })); toast("Pengalihan otomatis diblokir"); return false; }
    return true;
  };
  const onMsg = tid => e => {
    try { const m = JSON.parse(e.nativeEvent.data); if (m.t === "t") touch.current[tid] = Date.now(); if (m.t === "b") upd(tid, x => ({ n:x.n + 1 })); } catch {}
  };
  const onOpen = tid => e => {
    const u = e.nativeEvent.targetUrl;
    if (SH.current && (isAd(host(u)) || Date.now() - (touch.current[tid] || 0) > 1000)) { upd(tid, x => ({ n:x.n + 1 })); toast("Popup diblokir"); return; }
    openTab(u);
  };
  const loading = tab.p > 0 && tab.p < 1;

  return (
    <SafeAreaProvider>
      <SafeAreaView style={s.root} edges={["top","bottom"]}>
        <StatusBar style="light" />
        <View style={s.bar}>
          <Pressable onPress={toggleShield} style={s.sh} accessibilityLabel="Perisai iklan">
            <I name={shield ? "shield-checkmark" : "shield-outline"} size={20} color={shield ? C.cyan : C.mute} />
            {shield && tab.n > 0 && <Text style={s.cnt}>{tab.n > 99 ? "99+" : tab.n}</Text>}
          </Pressable>
          <TextInput style={s.input} value={focus ? text : host(tab.cur)} placeholder="Cari atau ketik alamat" placeholderTextColor={C.mute}
            autoCapitalize="none" autoCorrect={false} keyboardType="url" selectTextOnFocus returnKeyType="go"
            onFocus={() => { setText(tab.cur); setFocus(true); }} onBlur={() => setFocus(false)} onChangeText={setText} onSubmitEditing={() => go(text)} />
          {!!tab.src && <Pressable onPress={() => loading ? refs.current[id]?.stopLoading() : refs.current[id]?.reload()} style={s.ic}><I name={loading ? "close" : "reload"} size={20} color={C.mute} /></Pressable>}
        </View>
        <View style={s.progBox}>{loading && <View style={[s.prog, { width: `${tab.p * 100}%` }]} />}</View>

        <View style={{ flex:1 }}>
          {tabs.map(t => (
            <View key={t.id} style={[StyleSheet.absoluteFill, { display: t.id === id ? "flex" : "none" }]}>
              {t.src ? (
                <WebView ref={r => { refs.current[t.id] = r; }} source={{ uri:t.src }} style={{ backgroundColor:C.bg }}
                  injectedJavaScriptBeforeContentLoaded={inject(shield)} onMessage={onMsg(t.id)}
                  onShouldStartLoadWithRequest={guard(t.id)} setSupportMultipleWindows onOpenWindow={onOpen(t.id)}
                  onNavigationStateChange={n => upd(t.id, { cur:n.url, title:n.title || host(n.url), b:n.canGoBack, f:n.canGoForward })}
                  onLoadProgress={e => upd(t.id, { p:e.nativeEvent.progress })} onLoadEnd={() => upd(t.id, { p:1 })}
                  javaScriptEnabled domStorageEnabled thirdPartyCookiesEnabled={!shield} allowsBackForwardNavigationGestures />
              ) : (
                <View style={s.home}>
                  <Text style={s.logo}>Browku</Text>
                  <Text style={s.sub}>Pencarian tanpa filter, iklan dan popup diblokir.</Text>
                  <View style={s.chips}>{ENGINES.map((e, i) => (
                    <Pressable key={e.n} onPress={() => setEng(i)} style={[s.chip, i === eng && s.chipOn]}><Text style={{ color: i === eng ? C.text : C.mute }}>{e.n}</Text></Pressable>
                  ))}</View>
                  <View style={s.grid}>{QUICK.map(([n, u]) => (
                    <Pressable key={n} style={s.q} onPress={() => { touch.current[t.id] = Date.now(); upd(t.id, { src:u, cur:u }); }}>
                      <View style={s.qi}><Text style={s.qt}>{n[0]}</Text></View><Text style={{ color:C.text, fontSize:12 }}>{n}</Text>
                    </Pressable>
                  ))}</View>
                </View>
              )}
            </View>
          ))}
        </View>

        <View style={s.nav}>
          <Pressable style={s.nb} disabled={!tab.b} onPress={() => refs.current[id]?.goBack()}><I name="chevron-back" size={26} color={tab.b ? C.text : C.line} /></Pressable>
          <Pressable style={s.nb} disabled={!tab.f} onPress={() => refs.current[id]?.goForward()}><I name="chevron-forward" size={26} color={tab.f ? C.text : C.line} /></Pressable>
          <Pressable style={s.nb} onPress={() => openTab()}><I name="add" size={28} color={C.text} /></Pressable>
          <Pressable style={s.nb} onPress={() => setSw(true)}><View style={s.cntBox}><Text style={s.cntTxt}>{tabs.length}</Text></View></Pressable>
        </View>

        {sw && (
          <View style={s.sw}>
            <View style={s.swh}><Text style={s.swt}>{tabs.length} tab</Text><Pressable onPress={() => setSw(false)}><Text style={{ color:C.cyan, fontWeight:"700" }}>Selesai</Text></Pressable></View>
            <FlatList data={tabs} numColumns={2} keyExtractor={t => t.id} contentContainerStyle={{ padding:10 }} renderItem={({ item }) => (
              <Pressable style={[s.card, item.id === id && { borderColor:C.cyan }]} onPress={() => { setAid(item.id); setSw(false); }}>
                <View style={s.cardTop}><Text numberOfLines={1} style={s.cardT}>{item.title}</Text>
                  <Pressable hitSlop={10} onPress={() => closeTab(item.id)}><I name="close" size={18} color={C.mute} /></Pressable></View>
                <Text numberOfLines={1} style={s.cardH}>{item.cur ? host(item.cur) : "Halaman baru"}</Text>
                {item.n > 0 && <Text style={s.cardN}>{item.n} diblokir</Text>}
              </Pressable>
            )} />
            <Pressable style={s.newBtn} onPress={() => openTab()}><Text style={{ color:"#06242a", fontWeight:"700" }}>Tab baru</Text></Pressable>
          </View>
        )}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const s = StyleSheet.create({
  root:{ flex:1, backgroundColor:C.bg },
  bar:{ flexDirection:"row", alignItems:"center", margin:10, marginBottom:6, backgroundColor:C.surf, borderRadius:16, borderWidth:1, borderColor:C.line, paddingHorizontal:6 },
  sh:{ flexDirection:"row", alignItems:"center", padding:8, gap:4 }, cnt:{ color:C.cyan, fontSize:12, fontWeight:"700" },
  input:{ flex:1, color:C.text, fontSize:15, paddingVertical:11 }, ic:{ padding:8 },
  progBox:{ height:2, marginHorizontal:12 }, prog:{ height:2, backgroundColor:C.cyan, borderRadius:1 },
  home:{ flex:1, alignItems:"center", paddingTop:60, paddingHorizontal:20 },
  logo:{ color:C.text, fontSize:30, fontWeight:"800", letterSpacing:-0.6 }, sub:{ color:C.mute, marginTop:6, marginBottom:22, textAlign:"center" },
  chips:{ flexDirection:"row", gap:8, marginBottom:28 }, chip:{ paddingHorizontal:14, paddingVertical:8, borderRadius:99, borderWidth:1, borderColor:C.line }, chipOn:{ backgroundColor:C.raise, borderColor:C.cyan },
  grid:{ flexDirection:"row", flexWrap:"wrap", justifyContent:"center", gap:18 }, q:{ width:84, alignItems:"center", gap:6 },
  qi:{ width:56, height:56, borderRadius:18, backgroundColor:C.raise, alignItems:"center", justifyContent:"center" }, qt:{ color:C.cyan, fontSize:22, fontWeight:"700" },
  nav:{ flexDirection:"row", borderTopWidth:1, borderTopColor:C.line, backgroundColor:C.surf }, nb:{ flex:1, alignItems:"center", paddingVertical:10 },
  cntBox:{ width:26, height:26, borderRadius:7, borderWidth:2, borderColor:C.text, alignItems:"center", justifyContent:"center" }, cntTxt:{ color:C.text, fontSize:13, fontWeight:"700" },
  sw:{ ...StyleSheet.absoluteFillObject, backgroundColor:C.bg, paddingTop:8 },
  swh:{ flexDirection:"row", justifyContent:"space-between", alignItems:"center", padding:16 }, swt:{ color:C.text, fontSize:20, fontWeight:"700" },
  card:{ flex:1, margin:6, padding:12, borderRadius:16, backgroundColor:C.surf, borderWidth:1.5, borderColor:C.line, minHeight:96, maxWidth:"48%" },
  cardTop:{ flexDirection:"row", justifyContent:"space-between", alignItems:"center", gap:6 }, cardT:{ color:C.text, fontWeight:"600", flex:1 }, cardH:{ color:C.mute, marginTop:6, fontSize:12 }, cardN:{ color:C.amber, marginTop:8, fontSize:12 },
  newBtn:{ margin:14, backgroundColor:C.cyan, borderRadius:14, padding:14, alignItems:"center" },
});
