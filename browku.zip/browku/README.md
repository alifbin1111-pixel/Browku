# Browku

Browser Android (Expo + react-native-webview): multi-tab, perisai iklan, blokir popup dan pengalihan otomatis.

## Build APK lewat GitHub
1. Unggah semua isi folder ini (termasuk `.github`) ke repo baru.
2. Actions → Build APK → Run workflow.
3. Unduh `browku-apk` dari Artifacts (atau buat tag `v1.0.0` untuk Releases).

Jalankan lokal: `npm install && npx expo install --fix && npx expo start`
