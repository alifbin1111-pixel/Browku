export const AD_HOSTS = ["doubleclick.net","googlesyndication.com","googleadservices.com","adservice.google.com","popads.net","popcash.net","propellerads.com","exoclick.com","adsterra.com","juicyads.com","trafficjunky.com","outbrain.com","taboola.com","adnxs.com","onclickads.net","clickadu.com","hilltopads.net","mgid.com","revcontent.com","admaven.com","a-ads.com","adcash.com","popcdn.net","ero-advertising.com","tsyndicate.com","bidvertiser.com","moatads.com","scorecardresearch.com","criteo.com","pubmatic.com","rubiconproject.com","adform.net"];

// Skrip yang disuntik sebelum halaman dimuat
export const inject = (on) => `(function(){
var H=${JSON.stringify(AD_HOSTS)},on=${on},lt=0,P=function(m){window.ReactNativeWebView.postMessage(m)};
function ad(u){try{var h=new URL(u,location.href).hostname;return H.some(function(d){return h===d||h.endsWith('.'+d)})}catch(e){return false}}
function hit(){P('{"t":"b"}')}
addEventListener('touchstart',function(){var x=Date.now();lt=x;if(!window.__t||x-window.__t>300){window.__t=x;P('{"t":"t"}')}},true);
if(!on)return;
var of=window.fetch;window.fetch=function(u){var s=typeof u==='string'?u:(u&&u.url);if(ad(s)){hit();return Promise.reject(new TypeError('blocked'))}return of.apply(this,arguments)};
var ox=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u){if(ad(u)){hit();arguments[1]='about:blank'}return ox.apply(this,arguments)};
var oo=window.open;window.open=function(u){if(Date.now()-lt<1000&&!ad(u))return oo.apply(this,arguments);hit();return null};
function sweep(r){if(!r.querySelectorAll)return;r.querySelectorAll('script[src],iframe[src],img[src],a[href]').forEach(function(e){if(ad(e.src||e.href)){e.remove();hit()}})}
new MutationObserver(function(m){m.forEach(function(x){x.addedNodes.forEach(function(e){if(e.nodeType===1)sweep(e)})})}).observe(document.documentElement,{childList:true,subtree:true});
document.addEventListener('DOMContentLoaded',function(){
var s=document.createElement('style');s.textContent='ins.adsbygoogle,[id^="google_ads"],[class*="adsbox"],[class*="ad-banner"],[class*="popup-ad"],[id*="ad-container"],iframe[src*="doubleclick"],iframe[src*="adsystem"]{display:none!important}';
document.head.appendChild(s);sweep(document)});
})();true;`;
